<?php
$servername = "localhost";
$username = "emr9018";
$password = "billbring";
$dbname = "emr9018";
// Create connection
$mysqli = new mysqli($servername, $username, $password, $dbname);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
else
{
  echo '<script>';
  echo 'console.log("Connection success")';
  echo '</script>';
}

?>

<?php
 # 	require "";
	if ($mysqli) {
	  if (isset($_GET['name']) && isset($_GET['comment'])) {
	  if( $_GET['name']!='' && $_GET['comment']!='' ){
	
          
    $id = $_POST['ID'];
	$name = $_POST['name'];
	$comment = $_POST['comment'];
          
    $stmt=$conn->prepare("INSERT INTO comments (id, name, comment) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $id, $name, $comment);
    $stmt->execute();
          
    echo "New records created successfully";
          
    $stmt->close();
    $mysqli->close();
          
          
          /*
			we are using client entered data - therefore we HAVE TO USE a prepared statement
            
            https://www.w3schools.com/php/php_mysql_prepared_statements.asp
            */
			#1)prepare my query
            
            #$stmt = $msqli->prepare("INSERT INTO MyGuests (firstname, lastname, email) VALUES (?, ?, ?)");

            
		#	2)bind
		#	3)execute
		#	4)close
		
		#$stmt=$mysqli->prepare();
		#$stmt->bind_param();
		#$stmt->execute();
		#$stmt->close();
	  }//end of if to make sure data is sent using $_GET
      }//end of isset
	  //get contents of table and send back...
      $sql = 'select name, comment from comments';
	  $res=$mysqli->query($sql);
	  if($res){
		while($rowHolder = mysqli_fetch_array($res,MYSQLI_ASSOC)){
			$records[] = $rowHolder;
		}
	  }
	}
?>
<!DOCTYPE html>
<html lang="en">
    	<link rel="stylesheet" type="text/css" href="assets/css/EX08.css">
<header>
Please Leave a Comment Under Here
</header>
    
<body>
    <div class = "forms">
<form action="EX08_index.php" method="GET">
    <p>Name: <input type="text" name="name" size="20" id="name" placeholder="Your Name" required></p>
    <p>Comments: </p>
    <textarea name="comments" rows="5" cols="65" id="comments" placeholder="Leave a comment here~!"></textarea> 
    	<br><input type="submit" class="submit" value="Comment!">

</form>
        </div>
<div class = "container">
    <p>Edward Riley</p>
<textarea disabled="" id="commentBox">This is a test.</textarea>    
    </div>
    
    
    </body>
</html>
